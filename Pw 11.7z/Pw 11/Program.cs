﻿using Pw_11;
using System;
using System.Collections;
using System.Collections.Generic;
namespace OOP_Practice
{
    class Program
    {
        static void Main(string[] args)
        {
            // Создание объекта репозитория для товаров
            var productRepository = new Repository<Product>();
            //Репозиторий для заказов
            var orderRepository = new Repository<Order>();
            var order1 = new Order(1, new Dictionary<string, int>
        {
            {"Нож", 30},
            {"Вилка", 25}              
        });
            var order2 = new Order(2, new Dictionary<string, int>
        {
            {"Ложка", 20}
        });
            orderRepository.Add(order1);
            orderRepository.Add(order2);
            // Добавление товаров
            productRepository.Add(new Product(1, "Laptop", 1200, "Electronics", 0));
            productRepository.Add(new Product(2, "Smartphone", 800,"Electronics", 53));
            productRepository.Add(new Product(3, "Chair", 150, "Furniture", 16));
            productRepository.Add(new Product(4, "Table", 300, "Furniture", 48));
            productRepository.Add(new Product(5, "TV", 1000, "Electronics", 98));
            // LINQ-запрос: найти все товары в категории "Electronics"
            var electronics = productRepository.GetAll()
            .Where(p => p.Category == "Electronics");
            Console.WriteLine("Товары в категории 'Electronics':");
            foreach (var product in electronics)
            {
                Console.WriteLine(product);
            }
            // LINQ-запрос: найти самый дорогой товар
            var mostExpensive = productRepository.GetAll()
            .OrderByDescending(p => p.Price)
            .FirstOrDefault();
            Console.WriteLine($"\nСамый дорогой товар: {mostExpensive}");
            // LINQ-запрос: отсортировать товары по цене
            var sortedByPrice = productRepository.GetAll()
            .OrderBy(p => p.Price);

            Console.WriteLine("\nТовары, отсортированные по цене:");
            foreach (var product in sortedByPrice)
            {
                Console.WriteLine(product);
            }
            // LINQ-запрос: посчитать общее количество товаров
            var totalProducts = productRepository.GetAll().Count();
            Console.WriteLine($"\nОбщее количество товаров: {totalProducts}");
            // LINQ-запрос: всех товаров на складе
            var sortedByAmount = productRepository.GetAll()
                .Where(p => p.Stock > 0)
                .OrderBy(p => p.Stock);

            foreach (var product in sortedByAmount)
            {
                Console.WriteLine($"Общее количество товаров на складе: {product}");
            }
            //LINQ-запрос: все заказы с определенным товаром
            var ordersWithKnife = orderRepository.GetAll();
            Console.WriteLine("Заказы содержащие столовые приборы:");
            foreach (var order in ordersWithKnife)
            {
                Console.WriteLine(order);
            }         
        }
    }
}
