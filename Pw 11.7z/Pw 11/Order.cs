﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pr_11
{
    class Order
    {
        public int OrderId { get; set; } // ID заказа
        public Dictionary<string, int> Items { get; set; } // Список товаров и их количества

        public Order(int orderId, Dictionary<string, int> items)
        {
            OrderId = orderId;
            Items = items;
        }

        public override string ToString()
        {
            return $"ID заказа: {OrderId}, Заказы: {string.Join(", ", Items)}";
        }
    }
}
