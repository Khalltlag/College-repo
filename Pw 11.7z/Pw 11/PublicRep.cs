﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pw_11
{
    class PublicRep<T>
    {
        private List<T> _items = new List<T>();

        public void Add(T item)
        {
            _items.Add(item);
        }

        public IEnumerable<T> GetAll()
        {
            return _items;
        }

        public IEnumerable<Order> GetOrdersByItem(string item)
        {
            return _items.OfType<Order>()
                .Where(order => order.Items.ContainsKey(item) && order.Items[item] > 0);
        }

    }
}
